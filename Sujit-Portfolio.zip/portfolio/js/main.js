/* ==========================================================
   Sujit Kumar Patel | Portfolio - shared JavaScript
   Handles: mobile menu, blog "Read More", contact form.
   ========================================================== */

// ---- EDIT HERE: the email address that receives contact form messages ----
const CONTACT_EMAIL = "spkumar30092007@gmail.com";

document.addEventListener("DOMContentLoaded", function () {
  setupMobileMenu();
  setupReadMore();
  setupContactForm();
});

/* ---------- Mobile navigation ---------- */
function setupMobileMenu() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("main-nav");
  if (!toggle || !nav) return;

  toggle.addEventListener("click", function () {
    const isOpen = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(isOpen));
  });
}

/* ---------- Blog: Read More / Show Less ---------- */
function setupReadMore() {
  document.querySelectorAll(".post").forEach(function (post) {
    const button = post.querySelector(".read-more");
    if (!button) return;

    button.addEventListener("click", function () {
      const open = post.classList.toggle("open");
      button.textContent = open ? "Show Less" : "Read More";
      button.setAttribute("aria-expanded", String(open));
    });
  });
}

/* ---------- Contact form (honest mailto approach) ----------
   This site has no server, so it cannot send email by itself.
   When the form is valid, it opens the visitor's email app with
   the message pre-filled. The message is only sent when the
   visitor presses Send there. The page says so clearly.
   To use a real form service later (Formspree, Web3Forms, etc.),
   see the README section "Connecting a real form service".
---------------------------------------------------------- */
function setupContactForm() {
  const form = document.getElementById("contact-form");
  if (!form) return;

  const status = document.getElementById("form-status");
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function showError(field, message) {
    field.classList.add("invalid");
    field.setAttribute("aria-invalid", "true");
    const slot = document.getElementById(field.id + "-error");
    if (slot) slot.textContent = message;
  }

  function clearError(field) {
    field.classList.remove("invalid");
    field.removeAttribute("aria-invalid");
    const slot = document.getElementById(field.id + "-error");
    if (slot) slot.textContent = "";
  }

  function showStatus(message, isError) {
    status.textContent = message;
    status.className = "form-status show" + (isError ? " error" : "");
  }

  form.querySelectorAll("input, textarea").forEach(function (field) {
    field.addEventListener("input", function () { clearError(field); });
  });

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    const name = form.elements["name"];
    const email = form.elements["email"];
    const subject = form.elements["subject"];
    const message = form.elements["message"];
    let valid = true;
    let firstBad = null;

    [name, email, subject, message].forEach(clearError);

    if (!name.value.trim()) { showError(name, "Please enter your full name."); valid = false; firstBad = firstBad || name; }
    if (!email.value.trim()) {
      showError(email, "Please enter your email address."); valid = false; firstBad = firstBad || email;
    } else if (!emailPattern.test(email.value.trim())) {
      showError(email, "Please enter a valid email address, for example name@example.com."); valid = false; firstBad = firstBad || email;
    }
    if (!subject.value.trim()) { showError(subject, "Please enter a subject."); valid = false; firstBad = firstBad || subject; }
    if (message.value.trim().length < 10) { showError(message, "Please write a message of at least 10 characters."); valid = false; firstBad = firstBad || message; }

    if (!valid) {
      showStatus("Please fix the highlighted fields and try again. Nothing has been sent.", true);
      if (firstBad) firstBad.focus();
      return;
    }

    const body =
      "Name: " + name.value.trim() + "\n" +
      "Email: " + email.value.trim() + "\n\n" +
      message.value.trim();

    const mailto =
      "mailto:" + CONTACT_EMAIL +
      "?subject=" + encodeURIComponent(subject.value.trim()) +
      "&body=" + encodeURIComponent(body);

    showStatus(
      "Your email app should now open with the message filled in. The message has NOT been sent yet - please press Send in your email app. " +
      "If nothing opened, email me directly at " + CONTACT_EMAIL + ".",
      false
    );

    window.location.href = mailto;
  });
}
