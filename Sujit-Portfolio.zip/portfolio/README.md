# Sujit Kumar Patel | Portfolio

A four-page personal portfolio built with plain HTML, CSS and JavaScript. No frameworks, no installs, no build step.

## Folder structure

```
portfolio/
├── index.html      About Me
├── blogs.html      Blogs (3 posts)
├── projects.html   Technical Projects
├── links.html      Links & Accounts + Let's Connect form
├── css/style.css   All styling (colours and fonts are at the top)
├── js/main.js      Mobile menu, Read More buttons, contact form
├── images/         Empty; put any future images here
└── README.md
```

## Run it locally

**Easiest:** double-click `index.html`. It opens in your browser.

**Optional (local server):** open a terminal in the `portfolio` folder and run

```
python -m http.server 8000
```

then visit http://localhost:8000.

## What to edit

Search each file for `EDIT HERE` comments. The main ones:

| What | Where |
|---|---|
| Intro text, skills, internship details | `index.html` |
| Blog titles, dates, text | `blogs.html` |
| Project details, live site and source code buttons | `projects.html` |
| Other accounts (HackerRank, LeetCode) | `links.html` |
| Colours and fonts | top of `css/style.css` |
| Email that receives form messages | top of `js/main.js` |

## Publish for free with GitHub Pages

1. Sign in at github.com and click **New repository**. Name it `sujitpatel2007.github.io` (gives you the URL `https://sujitpatel2007.github.io`) or any name such as `portfolio` (URL becomes `https://sujitpatel2007.github.io/portfolio/`).
2. Set it to **Public** and create it.
3. Click **uploading an existing file**, drag in everything inside the `portfolio` folder (`index.html`, `blogs.html`, `projects.html`, `links.html`, `css`, `js`, `images`, `README.md`) and commit.
4. Go to **Settings > Pages**. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait one or two minutes. GitHub shows your live URL on the same page.
6. Come back to `projects.html`:
   - On the Personal Digital Portfolio project, replace the "Live Website Coming Soon" button's `href="#"` with your live URL, remove `aria-disabled="true"` and `onclick="return false;"`, and change the text to **View Live Portfolio**.
   - Do the same with the repository URL for **View Source Code**.
7. Upload the changed `projects.html` to the repository again.

## Connecting a real form service (optional)

The form currently uses `mailto:`, so it opens the visitor's email app. To receive messages directly, use a free service such as Formspree or Web3Forms: create a form there, then change the `<form>` tag in `links.html` to use the service's `action` URL with `method="POST"`, and replace the `mailto` code in `js/main.js` with a `fetch()` call to that URL. Only show the success message after the service confirms the request worked.

## Submission checklist

**Pages and navigation**
- [ ] All four pages open: About Me, Blogs, Technical Projects, Links & Accounts
- [ ] The current page is highlighted in the menu on each page
- [ ] The Menu button works on a phone-sized window
- [ ] Header and footer look the same on every page
- [ ] Page title in the browser tab is "Sujit Kumar Patel | Portfolio"

**About Me**
- [ ] View My Resume opens the Drive folder in a new tab
- [ ] Watch My Self-Introduction opens YouTube in a new tab
- [ ] Embedded video plays
- [ ] Internship document button opens the Thiranex file
- [ ] Both certificate "View Certificate" buttons open
- [ ] Email, GitHub and LinkedIn links work
- [ ] Check the Drive files are shared as "Anyone with the link can view", otherwise visitors will see "Access denied"

**Blogs**
- [ ] Read More / Show Less works on all three posts
- [ ] You have read the posts and they match your own experience; edit anything that does not

**Projects**
- [ ] View Project on GitHub opens the Sales Dashboard repository
- [ ] You checked the repository and the features listed match what you built
- [ ] Live site and source code buttons updated after deployment

**Links & Accounts**
- [ ] GitHub, LinkedIn, Resume and YouTube buttons all work
- [ ] HackerRank and LeetCode still say Coming Soon (or have real links)
- [ ] Submitting an empty form shows error messages
- [ ] A wrong email such as `abc` shows an error
- [ ] A valid form opens your email app and the page says the message is not sent yet

**Final**
- [ ] Open the published URL on your phone
- [ ] Submit the live URL (and repository URL) to your college
